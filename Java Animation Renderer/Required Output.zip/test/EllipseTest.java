//import org.junit.Before;
//import org.junit.Test;
//
//import Ellipse;
//
//import static org.junit.Assert.assertEquals;
//
//
///**
// * tests the toString for the Ellipse class.
// */
//public class EllipseTest {
//  private Ellipse ellipse;
//
//  @Before
//  public void setUp() throws Exception {
//    ellipse = new Ellipse(1, 2, 3, 4, 5, 6, 7, 8, 8,
//            "A");
//  }
//
//  @Test
//  public void toString1() {
//    assertEquals("\nType: Ellipse\n" +
//            "Min Corner: (1,2), Width: 3.0, Height: 4.0, Color: (5,6,7)\n" +
//            "Appears at: ***STARTTIME***\n" +
//            "Disappears at: ***ENDTIMR***\n", ellipse.toString());
//
//
//  }
//}